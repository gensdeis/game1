var searchData=
[
  ['bitfield_5foperation_5ftype',['bitfield_operation_type',['../classcpp__redis_1_1client.html#a2e2023534299541da0a659802e2f087d',1,'cpp_redis::client']]]
];
