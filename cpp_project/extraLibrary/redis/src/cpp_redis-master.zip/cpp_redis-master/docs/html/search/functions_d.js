var searchData=
[
  ['tcp_5fclient',['tcp_client',['../classcpp__redis_1_1network_1_1tcp__client.html#a8cbad07ca636e9d60dafc0e5cac8106d',1,'cpp_redis::network::tcp_client']]],
  ['tcp_5fclient_5fiface',['tcp_client_iface',['../classcpp__redis_1_1network_1_1tcp__client__iface.html#a8504873049519bcebd626984e4087a90',1,'cpp_redis::network::tcp_client_iface']]]
];
