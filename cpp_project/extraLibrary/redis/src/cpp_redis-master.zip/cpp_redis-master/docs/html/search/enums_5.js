var searchData=
[
  ['overflow_5ftype',['overflow_type',['../classcpp__redis_1_1client.html#a4119182ad3a01c1bb626a174375e114a',1,'cpp_redis::client']]]
];
