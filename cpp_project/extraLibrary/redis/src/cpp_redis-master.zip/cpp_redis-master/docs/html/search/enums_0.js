var searchData=
[
  ['aggregate_5fmethod',['aggregate_method',['../classcpp__redis_1_1client.html#aa197ca5b36da793c701d3ba388ec4946',1,'cpp_redis::client']]]
];
