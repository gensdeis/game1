var searchData=
[
  ['warn',['warn',['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efea1ea4c3ab05ee0c6d4de30740443769cb',1,'tacopie::logger']]]
];
