var searchData=
[
  ['tacopie',['tacopie',['../namespacetacopie.html',1,'']]],
  ['tacopie_5ferror',['tacopie_error',['../classtacopie_1_1tacopie__error.html',1,'tacopie::tacopie_error'],['../classtacopie_1_1tacopie__error.html#a524fb8e9ac1825a57664421a3f32b9ce',1,'tacopie::tacopie_error::tacopie_error(const std::string &amp;what, const std::string &amp;file, std::size_t line)'],['../classtacopie_1_1tacopie__error.html#a0cb2a911165e08818ca03308891633e1',1,'tacopie::tacopie_error::tacopie_error(const tacopie_error &amp;)=default']]],
  ['task_5ft',['task_t',['../classtacopie_1_1utils_1_1thread__pool.html#a8ae8886fdeaa8e5c0abad12626a47296',1,'tacopie::utils::thread_pool']]],
  ['tcp_5fclient',['tcp_client',['../classtacopie_1_1tcp__client.html',1,'tacopie::tcp_client'],['../classtacopie_1_1tcp__client.html#a0125e1cf017b0ba0370d682d4382d37b',1,'tacopie::tcp_client::tcp_client(std::uint32_t num_io_workers=1)'],['../classtacopie_1_1tcp__client.html#a773fbcbb5b79324c8d065e363de73282',1,'tacopie::tcp_client::tcp_client(tcp_socket &amp;&amp;socket)'],['../classtacopie_1_1tcp__client.html#a5e326782c52f63814cc8f42a901ffaf6',1,'tacopie::tcp_client::tcp_client(const tcp_client &amp;)=delete']]],
  ['tcp_5fclient_2ehpp',['tcp_client.hpp',['../tcp__client_8hpp.html',1,'']]],
  ['tcp_5fserver',['tcp_server',['../classtacopie_1_1tcp__server.html',1,'tacopie::tcp_server'],['../classtacopie_1_1tcp__server.html#a4f67a38a0764924768cbcc7cf68527bf',1,'tacopie::tcp_server::tcp_server(void)'],['../classtacopie_1_1tcp__server.html#a2d9c6a2dea95a3c6a919c655d6e8e0ba',1,'tacopie::tcp_server::tcp_server(const tcp_server &amp;)=delete']]],
  ['tcp_5fserver_2ehpp',['tcp_server.hpp',['../tcp__server_8hpp.html',1,'']]],
  ['tcp_5fsocket',['tcp_socket',['../classtacopie_1_1tcp__socket.html',1,'tacopie::tcp_socket'],['../classtacopie_1_1tcp__socket.html#a88ed1cadb0263591c4d31805e0a1a001',1,'tacopie::tcp_socket::tcp_socket(void)'],['../classtacopie_1_1tcp__socket.html#a191ffa48e0753ad4ec87d4d3a4a97822',1,'tacopie::tcp_socket::tcp_socket(fd_t fd, const std::string &amp;host, std::uint32_t port, type t)'],['../classtacopie_1_1tcp__socket.html#a64f69cd1c185b523b543d4ea53cee1a2',1,'tacopie::tcp_socket::tcp_socket(tcp_socket &amp;&amp;)'],['../classtacopie_1_1tcp__socket.html#a5ae1a5b0f9713ef256164afdbeb1c193',1,'tacopie::tcp_socket::tcp_socket(const tcp_socket &amp;)=delete']]],
  ['tcp_5fsocket_2ehpp',['tcp_socket.hpp',['../tcp__socket_8hpp.html',1,'']]],
  ['thread_5fpool',['thread_pool',['../classtacopie_1_1utils_1_1thread__pool.html',1,'tacopie::utils::thread_pool'],['../classtacopie_1_1utils_1_1thread__pool.html#aa0068f000b8ecb21b2b0a0c50f77877c',1,'tacopie::utils::thread_pool::thread_pool(std::size_t nb_threads)'],['../classtacopie_1_1utils_1_1thread__pool.html#a63a850c39d21058eda9d655bb7eff452',1,'tacopie::utils::thread_pool::thread_pool(const thread_pool &amp;)=delete']]],
  ['thread_5fpool_2ehpp',['thread_pool.hpp',['../thread__pool_8hpp.html',1,'']]],
  ['track',['track',['../classtacopie_1_1io__service.html#a9f4c8bce3c0f6d660515b0b5eb109df8',1,'tacopie::io_service']]],
  ['tracked_5fsocket',['tracked_socket',['../structtacopie_1_1io__service_1_1tracked__socket.html',1,'tacopie::io_service::tracked_socket'],['../structtacopie_1_1io__service_1_1tracked__socket.html#aa2bb26f180847ad15e09f303a2adc9ee',1,'tacopie::io_service::tracked_socket::tracked_socket()']]],
  ['type',['type',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172ab',1,'tacopie::tcp_socket']]],
  ['typedefs_2ehpp',['typedefs.hpp',['../typedefs_8hpp.html',1,'']]],
  ['utils',['utils',['../namespacetacopie_1_1utils.html',1,'tacopie']]]
];
