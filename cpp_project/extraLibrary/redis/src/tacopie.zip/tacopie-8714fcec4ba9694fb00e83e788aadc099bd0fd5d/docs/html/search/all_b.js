var searchData=
[
  ['self_5fpipe',['self_pipe',['../classtacopie_1_1self__pipe.html',1,'tacopie::self_pipe'],['../classtacopie_1_1self__pipe.html#add8d2c43863d1505e6851789ab5d9b97',1,'tacopie::self_pipe::self_pipe(void)'],['../classtacopie_1_1self__pipe.html#a09ffc77b89ad48bc8db6635108c68b6b',1,'tacopie::self_pipe::self_pipe(const self_pipe &amp;)=delete']]],
  ['send',['send',['../classtacopie_1_1tcp__socket.html#a36521a8f502adc665ad0fb1c53583d04',1,'tacopie::tcp_socket']]],
  ['set_5fnb_5fthreads',['set_nb_threads',['../classtacopie_1_1utils_1_1thread__pool.html#a7c7ae922cedff8fa323828ebb6dea829',1,'tacopie::utils::thread_pool']]],
  ['set_5fnb_5fworkers',['set_nb_workers',['../classtacopie_1_1io__service.html#a7e2b0700c0a4591f86c344df8748b3a5',1,'tacopie::io_service']]],
  ['set_5fon_5fdisconnection_5fhandler',['set_on_disconnection_handler',['../classtacopie_1_1tcp__client.html#a8c290d681186edb0578051c04f3c0762',1,'tacopie::tcp_client']]],
  ['set_5frd_5fcallback',['set_rd_callback',['../classtacopie_1_1io__service.html#a8094c1fec76c6821cc0c008fe524c89a',1,'tacopie::io_service']]],
  ['set_5ftype',['set_type',['../classtacopie_1_1tcp__socket.html#a89be86ab254eec3fc16eedfba8b16fb2',1,'tacopie::tcp_socket']]],
  ['set_5fwr_5fcallback',['set_wr_callback',['../classtacopie_1_1io__service.html#a7c4f56c7790c7ba52b09837a42aaffb1',1,'tacopie::io_service']]],
  ['size',['size',['../structtacopie_1_1tcp__client_1_1write__result.html#acee9eca954a6f1b6283c6188eead2ab1',1,'tacopie::tcp_client::write_result::size()'],['../structtacopie_1_1tcp__client_1_1read__request.html#ad8b69f61884c60596aface363ca947a3',1,'tacopie::tcp_client::read_request::size()']]],
  ['start',['start',['../classtacopie_1_1tcp__server.html#a6cb98b50d865b32dba497273a0eca1e9',1,'tacopie::tcp_server']]],
  ['stop',['stop',['../classtacopie_1_1tcp__server.html#abc099e162432e2218faed93fc84180fd',1,'tacopie::tcp_server::stop()'],['../classtacopie_1_1utils_1_1thread__pool.html#a8874d7040d12fbe446519bc9f2bcff37',1,'tacopie::utils::thread_pool::stop()']]],
  ['success',['success',['../structtacopie_1_1tcp__client_1_1read__result.html#a9bb917b8d210159a95655a6f8da8e96e',1,'tacopie::tcp_client::read_result::success()'],['../structtacopie_1_1tcp__client_1_1write__result.html#a4a8d5706c83068a97c10e63c6080e6a3',1,'tacopie::tcp_client::write_result::success()']]]
];
