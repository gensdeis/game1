var searchData=
[
  ['wait_5ffor_5fremoval',['wait_for_removal',['../classtacopie_1_1io__service.html#aa57db619baeaa6db0aeb22e67b895cd7',1,'tacopie::io_service']]],
  ['warn',['warn',['../classtacopie_1_1logger__iface.html#ab96d8f6bc2e2b514c7ceec4c856f8921',1,'tacopie::logger_iface::warn()'],['../classtacopie_1_1logger.html#aa4cd2ffc3f4b9d096a35c5c2aa8e0970',1,'tacopie::logger::warn(const std::string &amp;msg, const std::string &amp;file, std::size_t line)'],['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efea1ea4c3ab05ee0c6d4de30740443769cb',1,'tacopie::logger::warn()'],['../namespacetacopie.html#ac0a2f06f2f9fb6ded97b659d8573c25d',1,'tacopie::warn()']]],
  ['wr_5fcallback',['wr_callback',['../structtacopie_1_1io__service_1_1tracked__socket.html#ae46fc6ee7102027316eceff64116ba9d',1,'tacopie::io_service::tracked_socket']]],
  ['write_5frequest',['write_request',['../structtacopie_1_1tcp__client_1_1write__request.html',1,'tacopie::tcp_client']]],
  ['write_5fresult',['write_result',['../structtacopie_1_1tcp__client_1_1write__result.html',1,'tacopie::tcp_client']]]
];
