var searchData=
[
  ['info',['info',['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efeacaf9b6b99962bf5c2264824231d7a40c',1,'tacopie::logger']]]
];
