var searchData=
[
  ['rd_5fcallback',['rd_callback',['../structtacopie_1_1io__service_1_1tracked__socket.html#a4e44d4d8132f5272de80e83156d44fc6',1,'tacopie::io_service::tracked_socket']]]
];
