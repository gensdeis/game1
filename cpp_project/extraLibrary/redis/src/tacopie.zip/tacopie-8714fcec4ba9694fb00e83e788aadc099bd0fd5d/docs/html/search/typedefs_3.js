var searchData=
[
  ['on_5fnew_5fconnection_5fcallback_5ft',['on_new_connection_callback_t',['../classtacopie_1_1tcp__server.html#a103cb4e6fcab00f88a708aabd38b66ff',1,'tacopie::tcp_server']]]
];
