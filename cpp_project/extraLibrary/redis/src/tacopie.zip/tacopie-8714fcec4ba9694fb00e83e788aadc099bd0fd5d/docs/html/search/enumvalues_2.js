var searchData=
[
  ['error',['error',['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efeacb5e100e5a9a3e7f6d1fd97512215282',1,'tacopie::logger']]]
];
