var searchData=
[
  ['async_5fread_5fcallback',['async_read_callback',['../structtacopie_1_1tcp__client_1_1read__request.html#a3d495e82e38efebf763f595392b0db46',1,'tacopie::tcp_client::read_request']]],
  ['async_5fwrite_5fcallback',['async_write_callback',['../structtacopie_1_1tcp__client_1_1write__request.html#a04fd3e5484ba322d0112024bf8823623',1,'tacopie::tcp_client::write_request']]]
];
