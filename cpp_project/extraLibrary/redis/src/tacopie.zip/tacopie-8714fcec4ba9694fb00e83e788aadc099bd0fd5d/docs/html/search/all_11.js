var searchData=
[
  ['unknown',['UNKNOWN',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172aba696b031073e74bf2cb98e5ef201d4aa3',1,'tacopie::tcp_socket']]],
  ['untrack',['untrack',['../classtacopie_1_1io__service.html#a9a7672f0894a0fc1a3e6c593ca6df22c',1,'tacopie::io_service']]]
];
