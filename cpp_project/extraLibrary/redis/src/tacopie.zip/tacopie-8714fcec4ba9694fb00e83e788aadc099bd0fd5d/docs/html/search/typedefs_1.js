var searchData=
[
  ['disconnection_5fhandler_5ft',['disconnection_handler_t',['../classtacopie_1_1tcp__client.html#aca5df52e5ee6fa673cf212532ada1453',1,'tacopie::tcp_client']]]
];
